package com.example.mensajesrecyclerview

data class Message(val authorName: String, val imgAuthor: Int, val text: String)